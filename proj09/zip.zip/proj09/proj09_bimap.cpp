#include<iostream>
using std::cout; using std::endl;
#include<vector>
using std::vector;
#include<string>
using std::string; using std::to_string;
#include<algorithm>
using std::copy; using std::lower_bound; using std::find;
#include<iterator>
using std::ostream_iterator;
#include<sstream>
using std::ostringstream;
#include <utility>
using std::pair; using std::make_pair;


#include "proj09_bimap.h"
// if the string as a key is in the BiMap, do nothing and return false. Otherwise create a pair with the argument values and insert the new pair into the vectors, in sorted order, and return true.



BiMap::BiMap(initializer_list< pair<string, string> > vec){
    for( auto i = vec.begin();i< vec.end(); i++){
        add((*i).first,(*i).second);
    }
    
}

	// Uses lower_bound, returns an iterator to a pair<string, string> that is either the first pair in the vector that is equal to (by key) or greater than the key, or ordered_by_keys_.end() (the last two meaning that the key isn't in ordered_by_keys_)
	// Must be private because ordered_by_keys_ is private and we cannot return an iterator to a private data structure.
	
vector< pair <string, string> >::iterator BiMap::find_key(string key){
    
    auto itr = lower_bound(ordered_by_keys_.begin(), ordered_by_keys_.end(),key,[](pair<string,string> aa, string key) ->bool {return aa.first < key;});

    return itr;
    }
    
vector< pair <string, string> >::iterator BiMap::find_key1(string key){
    
    auto itr = lower_bound(ordered_by_vals_.begin(), ordered_by_vals_.end(),key,[](pair<string,string> aa, string key) ->bool {return aa.first < key;});
    //cout<<"geussing you are running"<<endl;
    //cout<<(*itr).first<<endl;
    return itr;
    }


vector< pair <string, string> >::iterator BiMap::find_value(string value){
	auto itr = lower_bound(ordered_by_vals_.begin(), ordered_by_vals_.end(),value,[](pair<string,string> aa, string value) ->bool {return aa.second < value;});

    return itr;
	}

vector< pair <string, string> >::iterator BiMap::find_value1(string value){
	auto itr = lower_bound(ordered_by_keys_.begin(), ordered_by_keys_.end(),value,[](pair<string,string> aa, string value) ->bool {return aa.second < value;});

    return itr;
	}
	
	
	// if the string as a key is in the BiMap, do nothing and return false. Otherwise create a pair with the argument values and insert the new pair into the vectors, in sorted order, and return true.
bool BiMap::add(string a, string b){
    
    auto aa =find_key(a);
    auto bb = find_value(b);
    pair<string,string> add = make_pair(a,b);
    //cout<<"here we have now "<<a<<":"<<b<<endl;
    //cout<<(aa == ordered_by_keys_.end()) <<endl;
    //cout<<(bb == ordered_by_vals_.end()) <<endl;
    
    for (size_t i =0; i<ordered_by_keys_.size();i++){
        
        if(ordered_by_keys_[i].first == a || ordered_by_keys_[i].second == b){
            
            
            return false;
        }
    }
    
    /*
    if (aa != ordered_by_keys_.end()  && bb != ordered_by_vals_.end()){

        return false;
    }
    */
    
    /*
    if ( (aa != ordered_by_keys_.end()  || bb != ordered_by_vals_.end())  ||(*aa).first == a || (*bb).second ==b){
        
        return false;
        }
    */
    
    
    
    if ((aa == ordered_by_keys_.end() || bb == ordered_by_vals_.end()) ){
        
        
        //cout<<"loooooooook"<<endl;
        
        if (ordered_by_keys_.size()==0){
            //cout<<"yyyyyyy"<<endl;
            ordered_by_keys_.push_back(add);
            ordered_by_vals_.push_back(add);
            return true;
        }
    
        else{
            
                
    ordered_by_keys_.insert(aa,add);
    ordered_by_vals_.insert(bb,add);
    
    return true;
    }
        }
        
        
        if (a==b){
            ordered_by_keys_.insert(aa,add);
              ordered_by_vals_.insert(bb,add);
              return true;
        }
        
            ordered_by_keys_.insert(aa,add);
             ordered_by_vals_.insert(bb,add);
        
        
        return true;
            
    }
// Returns the size of the BiMap (number of pairs) as an unsigned int
size_t BiMap::size(){
// Returns the size of the BiMap (number of pairs) as an unsigned int
    size_t in = ordered_by_keys_.size();
    return in;
    
    
    
    
}

	// Return the key associated with the value. If the value does not exist, then return the empty string.
string BiMap::key_from_value(string a){
    
    /*
    for (auto i = 0; i<ordered_by_keys_.size();i++){
        //cout<<ordered_by_keys_[i].second<<endl;
        if (ordered_by_keys_[i].second == a){
            return ordered_by_keys_[i].first;
        } 
    }
    return "";
    */
    if (find_value(a) == ordered_by_vals_.end() || (*find_value(a)).second != a ) {
        return "";
    }
    else{
        return (*find_value(a)).first;
    }
}

string BiMap::value_from_key(string b){
    
    if (find_key(b) == ordered_by_keys_.end() || (*find_key(b)).first != b ){
        return "";
    }
    
    else {
        return  (*find_key(b)).second;
    }
    
    /*
    
    for (auto i = 0; i<ordered_by_keys_.size(); i++){
        if(ordered_by_keys_[i].first == b){
            return ordered_by_keys_[i].second;
        }
    }
    return "";
*/
}    

// if the first string as a key is in the BiMap, update the key - value pair to the value of the second parameter. Return true. 
	// If the key is not in BiMap, do nothing and return false.
bool BiMap::update(string a, string b){
    for (size_t i = 0; i<ordered_by_keys_.size(); i++){
        
        //cout<<ordered_by_keys_[i].first<<" distinct"<<endl;
        if(ordered_by_keys_[i].first == a){
            ordered_by_keys_[i].second = b;
            ordered_by_vals_[i].second = b;
            //watch this
            //cout<<"runnsnisdnsdfaffsd"<<endl;
            return true;
        }
}
return false;
}

	// Look for element, as either a key or a value. If found, remove both the key and value from the BiMap and return that pair<key, value>(that order).
	// if the element does not exist as either a key or a value, return a pair of empty strings.
	// if element exists as both a key and a value, remove both pairs, and return a pair with the key that was associated with element, and the value that was associated with element.
pair<string, string> BiMap::remove(string a){

    pair<string,string> result;


    if (find_key(a) !=ordered_by_keys_.end() && find_value(a) != ordered_by_vals_.end() ){
        
        
        
        auto key_new = key_from_value(a);//8
        
        //auto pair1 = make_pair(key_new,a);
        
        
        auto val_new = value_from_key(a);  //2
        
        //auto pair2 = make_pair(a,val_new);
        
        
        //cout<<"key_new "<<key_new<<"val_enw "<<val_new<<endl;
        
        if (key_new == val_new ){
        
            if (a == key_new && a == val_new){
            
            ordered_by_keys_.erase(find_key(a));
            
            
            ordered_by_vals_.erase(find_value(a));
            //cout<<key_new<<":"<<val_new<<endl;
            
            
            return *(find_value(a));
            }
            
            
            ordered_by_keys_.erase(find_key(a));
            ordered_by_keys_.erase(find_key(key_new));
            
            ordered_by_vals_.erase(find_value(a));
            ordered_by_vals_.erase(find_value(val_new));
            
            return make_pair(a,a);
            
            
        }
        
        
        
        ordered_by_keys_.erase(find_key(a));
        ordered_by_keys_.erase(find_key(key_new));
        
        ordered_by_vals_.erase(find_value(a));
        //cout<<(*find_value(a)).first<<endl;_
        //cout<<(*find_value(val_new)).first<<endl;
        ordered_by_vals_.erase(find_value(val_new));
        //cout<<pair1.first<<":"<<pair2.second<<endl;
        cout<<key_new<<" : "<<val_new<<endl;
        auto cc = make_pair(val_new,key_new);
        return cc;
    }
    /*
    for (auto i = 0; i<ordered_by_keys_.size(); i++){
        
        cout<<(*find_key(a)).first<<endl;
        //cout<<(*find_value1(a)).first<<endl;
        
        cout<<key_from_value(a)<<endl;
        cout<<value_from_key(a)<<endl;
        
        if (key_from_value(a) !="" && value_from_key(a) != ""){
            
        cout<<"whynot papsjpf"<<endl;
        
        if( find_key(a) != ordered_by_keys_.end() && find_value1(a) != ordered_by_keys_.end()){
          
           
            
            auto a1 = (*(find_key(a))).first;
            auto b1 = (*(find_key1(a))).second;
            
            
            auto c1 = make_pair(a1,b1);
            
            ordered_by_keys_.erase(find_key(a));
            ordered_by_keys_.erase(find_value1(a));
            
            ordered_by_vals_.erase(find_key1(a));
            ordered_by_vals_.erase(find_value(a));
           
            return c1;
            
        }
        */
        
        else if (find_key(a) != ordered_by_keys_.end()){
            
            auto result = *(find_key(a));
            
            auto result1 = find(ordered_by_vals_.begin(),ordered_by_vals_.end(),result);
            
            
            ordered_by_keys_.erase(find_key(a));
            ordered_by_vals_.erase(result1);
            
            //cout<<"How Many running?"<<endl;
            return result;
        }
        
        else if (find_value(a) != ordered_by_vals_.end()){
            auto result = *(find_value(a));
            auto result1 = find(ordered_by_keys_.begin(),ordered_by_keys_.end(),result);
            
            ordered_by_vals_.erase(find_value(a));
            
            
            ordered_by_keys_.erase(result1);
             //cout<<"How Many running????"<<endl;
            return result;
        }
        
        else{
            return make_pair("","");
        }
        
     
        
}

int BiMap::compare(BiMap & bm){
    
    vector<string> vec;
    vector<string> vec1;
    size_t size;
    for (auto i =0; i<ordered_by_keys_.size(); i++){
        
        vec.push_back(ordered_by_keys_[i].first);
       
    }
    
    for (auto j=0; j<bm.ordered_by_keys_.size(); j++){
        vec1.push_back(bm.ordered_by_keys_[j].first);

        
    }
    
    
    
    
    auto size1 = ordered_by_keys_.size();
    auto size2 = bm.ordered_by_keys_.size();
    
    
    if(size1 > size2){
        size = bm.ordered_by_keys_.size();
    }
    else{
        size = ordered_by_keys_.size();
    }
    
    
    
    for (size_t z=0; z< size; z++){
        cout<<vec[z]<<" "<<vec1[z]<<endl;
        if (vec[z] != vec1[z]){
            
            if(vec[z]>vec1[z] ){
                return 1;
            }
            else if(vec[z]<vec1[z] ){
                return -1;
            }
        }
        
        
        
        
        else if (z ==size-1 && vec[z] == vec1[z]) {
            
            if(vec.size()>vec1.size()){
            
                return 1;
            }
            
            else if (vec.size()<vec1.size()){
                return -1;
            }
            
            else {
                return 0;
            }
            
            
        }
        
        
        
    }
    
    

    
}    
    
    
    
BiMap BiMap::merge(BiMap &bm ){
    
    BiMap bm_;
    bm_ = *this;
    
    for( auto i = 0;  i< bm.ordered_by_keys_.size(); i++){
        
        auto aa = bm_.find_key(bm.ordered_by_keys_[i].first);
        if (aa != bm_.ordered_by_keys_.end() && (*aa).first ==bm.ordered_by_keys_[i].first){
            continue;
            
        }
        
        else{
            
            bm_.ordered_by_keys_.insert(aa,bm.ordered_by_keys_[i]);
            
        }
    }
    
    
    return bm_;
}
    



   
ostream& operator<<(ostream& out, BiMap& BiMap){
    ostringstream oss;
    for (size_t i =0; i<BiMap.ordered_by_keys_.size();i++){
        
        oss<<BiMap.ordered_by_keys_[i].first<<" : "<<BiMap.ordered_by_keys_[i].second<<", ";
    }
    
    //cout<<"size for oss.str() is: "<<oss.str().size()<<endl;
    //oss.str().substr(0, (oss.str().size()-2));
    out<<oss.str().substr(0, (oss.str().size()-2));
    return out;
}
/*
ostream& operator<<(ostream& out, BiMap& BiMap){
    ostringstream oss;
    for (size_t i =0; i<BiMap.ordered_by_vals_.size();i++){
        
        oss<<BiMap.ordered_by_vals_[i].first<<" : "<<BiMap.ordered_by_vals_[i].second<<", ";
    }
    
    //cout<<"size for oss.str() is: "<<oss.str().size()<<endl;
    //oss.str().substr(0, (oss.str().size()-2));
    out<<oss.str().substr(0, (oss.str().size()-2));
    return out;
}
*/









